#===============================================================================
# Pokémon sprite (usado fuera de la batalla)
#===============================================================================
class PokemonSprite < SpriteWrapper
  def initialize(viewport=nil)
    super(viewport)
    @_iconbitmap=nil
  end

  def dispose
    @_iconbitmap.dispose if @_iconbitmap
    @_iconbitmap=nil
    self.bitmap=nil if !self.disposed?
    super
  end

  def update
    super
    if @_iconbitmap
      @_iconbitmap.update
      self.bitmap=@_iconbitmap.bitmap
    end
  end

  def setOffset(offset=PictureOrigin::Center)
    @offset=offset
    changeOrigin
  end

  def changeOrigin
    return if !self.bitmap
    @offset=PictureOrigin::Center if !@offset
    case @offset
    when PictureOrigin::TopLeft, PictureOrigin::Top, PictureOrigin::TopRight
      self.oy=0
    when PictureOrigin::Left, PictureOrigin::Center, PictureOrigin::Right
      self.oy=self.bitmap.height/2
    when PictureOrigin::BottomLeft, PictureOrigin::Bottom, PictureOrigin::BottomRight
      self.oy=self.bitmap.height
    end
    case @offset
    when PictureOrigin::TopLeft, PictureOrigin::Left, PictureOrigin::BottomLeft
      self.ox=0
    when PictureOrigin::Top, PictureOrigin::Center, PictureOrigin::Bottom
      self.ox=self.bitmap.width/2
    when PictureOrigin::TopRight, PictureOrigin::Right, PictureOrigin::BottomRight
      self.ox=self.bitmap.width
    end
  end

  def clearBitmap
    @_iconbitmap.dispose if @_iconbitmap
    @_iconbitmap=nil
    self.bitmap=nil
  end

  def setPokemonBitmap(pokemon,back=false)
    @_iconbitmap.dispose if @_iconbitmap
    @_iconbitmap=pokemon ? pbLoadPokemonBitmap(pokemon,back) : nil
    self.bitmap=@_iconbitmap ? @_iconbitmap.bitmap : nil
    self.color=Color.new(0,0,0,0)
  end

  def setPokemonBitmapSpecies(pokemon,species,back=false)
    @_iconbitmap.dispose if @_iconbitmap
    @_iconbitmap=pokemon ? pbLoadPokemonBitmapSpecies(pokemon,species,back) : nil
    self.bitmap=@_iconbitmap ? @_iconbitmap.bitmap : nil
  end

  def setSpeciesBitmap(species,female=false,form=0,shiny=false,shadow=false,back=false,egg=false)
    @_iconbitmap.dispose if @_iconbitmap
    @_iconbitmap=pbLoadSpeciesBitmap(species,female,form,shiny,shadow,back,egg)
    self.bitmap=@_iconbitmap ? @_iconbitmap.bitmap : nil
  end
end



#===============================================================================
# Pokémon sprite (usado en batalla)
#===============================================================================
class PokemonBattlerSprite < RPG::Sprite
  attr_accessor :selected

  def initialize(doublebattle,index,viewport=nil)
    super(viewport)
    @selected=0
    @frame=0
    @index=index
    @updating=false
    @doublebattle=doublebattle
    @index=index
    @spriteX=0
    @spriteY=0
    @spriteXExtra=0
    @spriteYExtra=0
    @spriteVisible=false
    @_iconbitmap=nil
    self.visible=false
  end

  def x
    return @spriteX
  end

  def y
    return @spriteY
  end

  def x=(value)
    @spriteX=value
    super(value+@spriteXExtra)
  end

  def y=(value)
    @spriteY=value
    super(value+@spriteYExtra)
  end

  def width; return (self.bitmap) ? self.bitmap.width : 0; end
  def height; return (self.bitmap) ? self.bitmap.height : 0; end

  def dispose
    @_iconbitmap.dispose if @_iconbitmap
    @_iconbitmap=nil
    self.bitmap=nil if !self.disposed?
    super
  end

  def selected=(value)
    if @selected==1 && value!=1 && @spriteYExtra>0
      @spriteYExtra=0
      self.y=@spriteY
    end
    @selected=value
  end

  def visible=(value)
    @spriteVisible=value if !@updating
    super
  end

  def setPokemonBitmap(pokemon,back=false)
    @_iconbitmap.dispose if @_iconbitmap
    @_iconbitmap=pbLoadPokemonBitmap(pokemon,back)
    self.bitmap=@_iconbitmap ? @_iconbitmap.bitmap : nil
  end

  def setPokemonBitmapSpecies(pokemon,species,back=false)
    @_iconbitmap.dispose if @_iconbitmap
    @_iconbitmap=pbLoadPokemonBitmapSpecies(pokemon,species,back)
    self.bitmap=@_iconbitmap ? @_iconbitmap.bitmap : nil
  end

  def update
    @frame+=1
    @updating=true
    @spriteYExtra=0
    # Pokémon sprite agitándose mientras es seleccionado el Pokémon
    if ((@frame/10).floor&1)==1 && @selected==1     # Cuando se escoge un comando para este Pokémon
      @spriteYExtra=2
    end
    self.x=@spriteX
    self.y=@spriteY
    self.visible=@spriteVisible
    # Pokémon sprite parpadeo cuando es apuntado o dañado
    if @spriteVisible && @selected==2       # Cuando es apuntado
      self.visible=(@frame%20<14)
    elsif @spriteVisible && @selected==3    # Cuando es dañado
      self.visible=(@frame%10<7)
    end
    if @_iconbitmap
      @_iconbitmap.update
      self.bitmap=@_iconbitmap.bitmap
    end
    @updating=false
  end
end



#===============================================================================
# Pokémon icon (para Pokémon definidos)
#===============================================================================
class PokemonIconSprite < SpriteWrapper
  attr_accessor :selected
  attr_accessor :active
  attr_reader :pokemon

  def initialize(pokemon,viewport=nil,animated=false)
    super(viewport)
    @animbitmap=nil
    @frames=[
       Rect.new(64,0,64,64),
       Rect.new(0,0,64,64),
    ]
    
    @selected=false
    @animframe=0
    @active=false
    @animated=animated
    self.pokemon=pokemon
    @frame=0
    @pokemon=pokemon
    @adjusted_x=0
    @adjusted_y=0
    @logical_x=0
    @logical_y=0
  end

  def pokemon=(value)
    @pokemon=value
    @animbitmap.dispose if @animbitmap
    @animbitmap=nil
    if @pokemon
      @animbitmap=AnimatedBitmap.new(pbPokemonIconFile(value))
      self.bitmap=@animbitmap.bitmap
      #ICONOS DINAMICOS
      sizeW=self.bitmap.width/2
      sizeH=self.bitmap.height
      @frames=[
        Rect.new(0,0,sizeW,sizeH),
        Rect.new(sizeW,0,sizeW,sizeH),
      ]
      #ICONOS DINAMICOS - FIN
      self.src_rect=@frames[@animframe]
    else
      self.bitmap=nil
    end
  end

  def dispose
    @animbitmap.dispose if @animbitmap
    super
  end

  def x
    @logical_x
  end

  def y
    @logical_y
  end

  def x=(value)
    @logical_x=value
    super(@logical_x+@adjusted_x)
  end

  def y=(value)
    @logical_y=value
    super(@logical_y+@adjusted_y)
  end

  def update
    @updating=true
    super
    if @animbitmap
      @animbitmap.update
      self.bitmap=@animbitmap.bitmap 
      self.src_rect=@frames[@animframe]
    end
    self.color=Color.new(0,0,0,0)
    unless @animated
      frameskip=5
      frameskip=10 if @pokemon && @pokemon.hp<=(@pokemon.totalhp/2)
      frameskip=20 if @pokemon && @pokemon.hp<=(@pokemon.totalhp/4)
      frameskip=-1 if @pokemon && @pokemon.hp==0
      if frameskip==-1
        @animframe=0
        self.src_rect=@frames[@animframe]
      else
        @frame+=1
        @frame=0 if @frame>100
        if @frame>=frameskip
          @animframe=(@animframe==1) ? 0 : 1
          self.src_rect=@frames[@animframe]
          @frame=0
        end
      end
      if self.selected
        @adjusted_x=4
        @adjusted_y=(@animframe==0) ? -2 : 6
      else
        @adjusted_x=0
        @adjusted_y=0
      end
    end
    @updating=false
    self.x=self.x
    self.y=self.y
    
  end
end



#===============================================================================
# Pokémon icon (para especies)
#===============================================================================
class PokemonSpeciesIconSprite < SpriteWrapper
  attr_accessor :selected
  attr_accessor :active
  attr_reader :species
  attr_reader :gender
  attr_reader :form

  def initialize(species,viewport=nil)
    super(viewport)
    @animbitmap=nil
    @frames=[
       Rect.new(0,0,64,64),
       Rect.new(64,0,64,64)
    ]
    @animframe=0
    @frame=0
    @x=0
    @y=0
    @species=species
    @gender=0
    @form=0
    refresh
  end

  def species=(value)
    @species=value
    refresh
  end

  def gender=(value)
    @gender=value
    refresh
  end

  def form=(value)
    @form=value
    refresh
  end

  def pbSetParams(species,gender,form)
    @species=species
    @gender=gender
    @form=form
    refresh
  end

  def dispose
    @animbitmap.dispose if @animbitmap
    super
  end

  def x; @x; end
  def y; @y; end

  def x=(value)
    @x=value
    super(@x)
  end

  def y=(value)
    @y=value
    super(@y)
  end

  def refresh
    @animbitmap.dispose if @animbitmap
    @animbitmap=nil
    bitmapFileName=pbCheckPokemonIconFiles([@species,(@gender==1),false,@form,false])
    @animbitmap=AnimatedBitmap.new(bitmapFileName)
    self.bitmap=@animbitmap.bitmap
    #ICONOS DINAMICOS
    sizeW = self.bitmap.width/2
    sizeH = self.bitmap.height
        
    @frames=[
      Rect.new(0,0,sizeW,sizeH),
      Rect.new(sizeW,0,sizeW,sizeH),
    ]
    #ICONOS DINAMICOS - FIN
    self.src_rect=@frames[@animframe]
  end

  def update
    @updating=true
    super
    if @animbitmap
      @animbitmap.update
      self.bitmap=@animbitmap.bitmap 
      self.src_rect=@frames[@animframe]
    end
    frameskip=5
    @frame+=1
    @frame=0 if @frame>10
    if @frame>=frameskip
      @animframe=(@animframe==1) ? 0 : 1
      self.src_rect=@frames[@animframe]
      @frame=0
    end
    @updating=false
    self.x=self.x
    self.y=self.y
  end
end



#===============================================================================
# Ajustes de la posición del sprite - MEJORADO BES-T
#===============================================================================
def getBattleSpriteMetricOffset(species,index,metrics=nil)
  metrics=load_data("Data/metrics.dat") if !metrics
  ret=0
  if index==1 || index==3   # Pokémon rival
    #ret+=(metrics[1][species] || 0)*2   # enemy Y
    ret-=(metrics[2][species] || 0)*2   # altitude
  else                      # Pokémon del jugador
    #ret+=(metrics[0][species] || 0)*2 
    ret-=48
  end
  return ret
end

def adjustBattleSpriteY(sprite, species, index, metrics=nil)
  ret = 0
  begin
    if sprite && sprite.bitmap && !sprite.bitmap.disposed?
      # Obtener el bottom edge visible del primer frame
      bottom_edge = pbGetSpriteBitmapBottomEdge(sprite.bitmap, 0)
      if bottom_edge
        # Posicionar basándose en la altura visible del contenido
        visible_height = bottom_edge + 1
        ret = -visible_height
      else
        # Fallback: usar altura completa del bitmap
        ret = -(sprite.bitmap.height rescue 128)
      end
    else
      ret = -128  # Fallback default
    end
    # Aplicar offset de métricas (altitude)
    ret += getBattleSpriteMetricOffset(species, index, metrics)
  rescue => e
    p "Error en adjustBattleSpriteY: #{e.message}" if $DEBUG
    ret = -128
  end
  return ret
end

def pbPositionPokemonSprite(sprite,left,top)
  if sprite.bitmap && !sprite.bitmap.disposed?
    sprite.x=left+(128-sprite.bitmap.width)/2
    sprite.y=top+(128-sprite.bitmap.height)/2
  else
    sprite.x=left
    sprite.y=top
  end
end

def pbSpriteSetCenter(sprite,cx,cy)
  return if !sprite
  if !sprite.bitmap
    sprite.x=cx
    sprite.y=cy
    return
  end
  realwidth=sprite.bitmap.width*sprite.zoom_x
  realheight=sprite.bitmap.height*sprite.zoom_y
  sprite.x=cx-(realwidth/2)
  sprite.y=cy-(realheight/2)
end

def showShadow?(species)
  #metrics=load_data("Data/metrics.dat")
  #return metrics[2][species]>0
  return  PokeBattle_SceneConstants::USE_BATTLE_SHADOWS
end

def pbCheckPokemonShadowBitmapFiles(species, form = 0, back = false)
  begin
    animated_bitmap = pbLoadSpeciesBitmap(species, false, form)
    return nil if !animated_bitmap
    bitmap = animated_bitmap.bitmap
    return nil if !bitmap || bitmap.disposed?
    width = bitmap.width rescue 0
    height = bitmap.height rescue 0
    return nil if width <= 0 || height <= 0
    left_edge = nil
    right_edge = nil
    # Búsqueda optimizada desde ambos lados
    left = 0
    right = width - 1
    step = [height / 10, 1].max  # Aumentar paso en altura para velocidad
    while left <= right
      # Buscar desde izquierda
      if left_edge.nil? && left < width
        y = 0
        while y < height
          begin
            if bitmap.get_pixel(left, y).alpha > 0
              left_edge = left
              break
            end
          rescue # Ignorar errores de píxel
          end
          y += step
        end
        left += 1 if left_edge.nil?
      end
      # Buscar desde derecha
      if right_edge.nil? && right >= 0
        y = 0
        while y < height
          begin
            if bitmap.get_pixel(right, y).alpha > 0
              right_edge = right
              break
            end
          rescue # Ignorar errores de píxel
          end
          y += step
        end
        right -= 1 if right_edge.nil?
      end
      # Salir si ambos bordes fueron encontrados
      break if left_edge && right_edge
    end
    # Calcular dimensiones visibles
    visible_width = (left_edge && right_edge) ? (right_edge - left_edge + 1) : 0
    dimension = visible_width
    dimension = (dimension * 1.5).to_i if back
    # Determinar tamaño
    size = 1  # small
    if dimension >= 170
      size = 4  # extra large
    elsif dimension >= 100
      size = 3  # large
    elsif dimension >= 70
      size = 2  # medium
    end
    bitmapFileName = sprintf("Graphics/Pictures/Battle/battler_shadow_%d", size)
    return bitmapFileName if pbResolveBitmap(bitmapFileName)
  rescue => e
    p "Error en pbCheckPokemonShadowBitmapFiles: #{e.message}" if $DEBUG
  end
  
  return nil
end

#===============================================================================
# DETECCIÓN DE BOTTOM EDGE - Para posicionamiento de sprites
#===============================================================================
def pbGetSpriteBitmapBottomEdge(bitmap, frame_index=0)
  begin
    return nil if !bitmap
    return nil if bitmap.disposed?
    width = bitmap.width rescue 0
    height = bitmap.height rescue 0
    return nil if width <= 0 || height <= 0
    # Calcular frame width basándose en estructura de sprite animado
    frame_width = height
    start_x = frame_index * frame_width
    end_x = [(frame_index + 1) * frame_width, width].min
    return nil if start_x >= width
    step = [height / 8, 1].max  # Aumentar paso para optimizar
    # Buscar desde abajo hacia arriba para encontrar el primer píxel visible
    y = height - 1
    while y >= 0
      x = start_x
      while x < end_x
        begin
          if bitmap.get_pixel(x, y).alpha > 0
            return y
          end
        rescue# Ignorar errores
        end
        x += 1
      end
      y -= step
    end
  rescue => e
    p "Error en pbGetSpriteBitmapBottomEdge: #{e.message}" if $DEBUG
  end
  return nil
end